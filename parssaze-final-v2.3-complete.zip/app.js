'use strict';

function openModal(id) {
  const el = document.getElementById(id);
  if (el) {
    el.style.display = 'flex';
    el.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal(id) {
  const el = document.getElementById(id);
  if (el) {
    el.style.display = 'none';
    el.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function toggleUserMenu() {
  const dd = document.getElementById('userDropdown');
  if (dd) dd.classList.toggle('active');
}

function toggleAdminMenu() {
  const sb = document.querySelector('.admin-sidebar');
  if (sb) sb.classList.toggle('mobile-open');
}

// بستن منوها با کلیک بیرون
window.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.style.display = 'none';
    e.target.classList.remove('active');
    document.body.style.overflow = '';
  }
  // بستن دراپ‌داون کاربر
  const userWrapper = document.querySelector('.user-dropdown-wrapper');
  const userDD = document.getElementById('userDropdown');
  if (userWrapper && userDD && !userWrapper.contains(e.target)) {
    userDD.classList.remove('active');
  }
});

// محو خودکار پیام‌ها
window.addEventListener('DOMContentLoaded', () => {
  const toast = document.getElementById('siteToast');
  if (toast) {
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(-20px)';
      toast.style.transition = 'all 0.4s ease';
      setTimeout(() => toast.remove(), 400);
    }, 4500);
  }

  // جستجوی زنده محصولات
  const searchInput = document.getElementById('liveSearch');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase();
      document.querySelectorAll('.pro-card').forEach(card => {
        const name = card.dataset.name?.toLowerCase() || '';
        const brand = card.dataset.brand?.toLowerCase() || '';
        const code = card.dataset.code?.toLowerCase() || '';
        const match = name.includes(q) || brand.includes(q) || code.includes(q);
        card.style.display = match ? '' : 'none';
      });
    });
  }

  // فیلتر دسته‌بندی در صفحه اصلی (کلاینت)
  document.querySelectorAll('[data-filter-cat]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-filter-cat]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.filterCat;
      document.querySelectorAll('.pro-card').forEach(card => {
        if (cat === 'all' || card.dataset.category === cat) {
          card.style.display = '';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // کپی کد پیگیری
  window.copyTracking = (code) => {
    navigator.clipboard.writeText(code).then(() => {
      showMiniToast('کد کپی شد: ' + code);
    });
  };

  // انیمیشن افزودن به سبد
  document.querySelectorAll('.btn-add-cart').forEach(btn => {
    btn.addEventListener('click', (e) => {
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> در حال افزودن...';
      setTimeout(() => {
        // فرم سابمیت خواهد شد، انیمیشن باقی می‌ماند تا ریدایرکت
      }, 300);
    });
  });
});

function showMiniToast(msg) {
  const t = document.createElement('div');
  t.textContent = msg;
  t.style.cssText = 'position:fixed;bottom:20px;right:20px;background:var(--navy);color:#fff;padding:10px 16px;border-radius:10px;z-index:9999;font-size:13px;box-shadow:0 4px 12px rgba(0,0,0,.2)';
  document.body.appendChild(t);
  setTimeout(() => {
    t.style.opacity = '0';
    t.style.transition = 'opacity .3s';
    setTimeout(() => t.remove(), 300);
  }, 2000);
}

// تایید حذف
function confirmDelete(msg) {
  return confirm(msg || 'آیا از حذف این مورد اطمینان دارید؟');
}

// پیش‌نمایش چاپ
function printInvoice() {
  window.print();
}

// تغییر تب داشبورد
function switchTab(tabName) {
  document.querySelectorAll('.tab-pane').forEach(p => p.style.display = 'none');
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  const pane = document.getElementById('tab-' + tabName);
  const btn = document.querySelector(`[data-tab="${tabName}"]`);
  if (pane) pane.style.display = 'block';
  if (btn) btn.classList.add('active');
  // ذخیره در URL بدون ریلود
  const url = new URL(window.location);
  url.searchParams.set('tab', tabName);
  window.history.replaceState({}, '', url);
}

// جستجوی سفارش
function trackOrderSubmit(e) {
  e.preventDefault();
  const code = document.getElementById('trackingInput')?.value.trim();
  if (!code) {
    showMiniToast('لطفاً کد پیگیری را وارد کنید');
    return;
  }
  window.location.href = 'index.php?page=track&code=' + encodeURIComponent(code);
}
