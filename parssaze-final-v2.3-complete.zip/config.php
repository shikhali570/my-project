<?php
// فعال‌سازی سشن ایمن
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Strict');
    session_start();
}

// ساخت توکن CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// هدرهای امنیتی
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("X-XSS-Protection: 1; mode=block");

// اتصال پایگاه داده SQLite
try {
    $db = new PDO('sqlite:' . __DIR__ . '/parssaze.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    // ساخت جداول اصلی - نسخه تخصصی 2.1
    $db->exec("
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            brand TEXT NOT NULL,
            price INTEGER NOT NULL,
            tax_id TEXT NOT NULL,
            stock INTEGER DEFAULT 10,
            icon TEXT DEFAULT '📦',
            description TEXT DEFAULT '',
            specs TEXT DEFAULT '',
            is_featured INTEGER DEFAULT 0,
            is_new INTEGER DEFAULT 0,
            discount_percent INTEGER DEFAULT 0,
            weight TEXT DEFAULT '',
            dimensions TEXT DEFAULT '',
            warranty TEXT DEFAULT '12 ماه گارانتی',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT UNIQUE NOT NULL,
            company TEXT,
            national_id TEXT,
            economic_code TEXT,
            postal_code TEXT,
            address TEXT,
            email TEXT DEFAULT '',
            province TEXT DEFAULT 'تهران',
            city TEXT DEFAULT 'تهران',
            role TEXT DEFAULT 'customer',
            status TEXT DEFAULT 'فعال',
            total_orders INTEGER DEFAULT 0,
            total_spent INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS invoices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_no TEXT UNIQUE NOT NULL,
            tax_unique_id TEXT UNIQUE NOT NULL,
            tracking_code TEXT NOT NULL,
            buyer_name TEXT NOT NULL,
            buyer_phone TEXT NOT NULL,
            buyer_tax_id TEXT,
            user_id INTEGER DEFAULT NULL,
            address_id INTEGER DEFAULT NULL,
            subtotal INTEGER NOT NULL,
            tax_amount INTEGER NOT NULL,
            discount_amount INTEGER DEFAULT 0,
            shipping_cost INTEGER DEFAULT 0,
            total_amount INTEGER NOT NULL,
            items_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'ثبت قطعی در سامانه مؤدیان',
            shipping_status TEXT DEFAULT 'در حال پردازش',
            payment_status TEXT DEFAULT 'پرداخت شده',
            payment_method TEXT DEFAULT 'پرداخت آنلاین',
            notes TEXT DEFAULT '',
            admin_notes TEXT DEFAULT '',
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS rfqs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rfq_code TEXT UNIQUE NOT NULL,
            company TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT DEFAULT '',
            description TEXT NOT NULL,
            budget TEXT DEFAULT '',
            urgency TEXT DEFAULT 'عادی',
            created_at TEXT NOT NULL,
            status TEXT DEFAULT 'جدید',
            user_id INTEGER DEFAULT NULL,
            admin_reply TEXT DEFAULT '',
            quoted_price INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            email TEXT DEFAULT '',
            role TEXT DEFAULT 'مدیر کل',
            permissions TEXT DEFAULT 'all',
            status TEXT DEFAULT 'فعال',
            last_login TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS order_status_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_id INTEGER NOT NULL,
            status TEXT NOT NULL,
            description TEXT,
            created_by TEXT DEFAULT 'سیستم',
            created_at TEXT NOT NULL,
            FOREIGN KEY(invoice_id) REFERENCES invoices(id)
        );

        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slug TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            icon TEXT DEFAULT '📦',
            description TEXT DEFAULT '',
            parent_id INTEGER DEFAULT 0,
            product_count INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS brands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slug TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            logo TEXT DEFAULT '',
            description TEXT DEFAULT '',
            website TEXT DEFAULT '',
            product_count INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS wishlist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(product_id) REFERENCES products(id),
            UNIQUE(user_id, product_id)
        );

        CREATE TABLE IF NOT EXISTS addresses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            province TEXT NOT NULL,
            city TEXT NOT NULL,
            address TEXT NOT NULL,
            postal_code TEXT,
            phone TEXT,
            receiver_name TEXT,
            is_default INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS support_tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_code TEXT UNIQUE NOT NULL,
            user_id INTEGER,
            subject TEXT NOT NULL,
            category TEXT DEFAULT 'عمومی',
            priority TEXT DEFAULT 'متوسط',
            message TEXT NOT NULL,
            status TEXT DEFAULT 'باز',
            admin_reply TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            type TEXT DEFAULT 'info',
            link TEXT DEFAULT '',
            is_read INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS coupons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            title TEXT NOT NULL,
            discount_percent INTEGER DEFAULT 0,
            discount_amount INTEGER DEFAULT 0,
            min_order INTEGER DEFAULT 0,
            max_uses INTEGER DEFAULT 1,
            used_count INTEGER DEFAULT 0,
            expires_at TEXT,
            is_active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS product_reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            rating INTEGER DEFAULT 5,
            comment TEXT,
            status TEXT DEFAULT 'تایید شده',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(product_id) REFERENCES products(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            admin_id INTEGER,
            action TEXT NOT NULL,
            description TEXT,
            ip TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
    ");

    // مهاجرت ستون‌های جدید برای سازگاری با دیتای قدیمی
    $tables = ['invoices', 'products', 'users', 'rfqs'];
    foreach ($tables as $table) {
        try {
            $existingCols = $db->query("PRAGMA table_info($table)")->fetchAll();
            $colNames = array_column($existingCols, 'name');
            if ($table === 'invoices') {
                if (!in_array('user_id', $colNames)) $db->exec("ALTER TABLE invoices ADD COLUMN user_id INTEGER DEFAULT NULL");
                if (!in_array('shipping_status', $colNames)) $db->exec("ALTER TABLE invoices ADD COLUMN shipping_status TEXT DEFAULT 'در حال پردازش'");
                if (!in_array('payment_status', $colNames)) $db->exec("ALTER TABLE invoices ADD COLUMN payment_status TEXT DEFAULT 'پرداخت شده'");
                if (!in_array('notes', $colNames)) $db->exec("ALTER TABLE invoices ADD COLUMN notes TEXT DEFAULT ''");
                if (!in_array('discount_amount', $colNames)) $db->exec("ALTER TABLE invoices ADD COLUMN discount_amount INTEGER DEFAULT 0");
                if (!in_array('shipping_cost', $colNames)) $db->exec("ALTER TABLE invoices ADD COLUMN shipping_cost INTEGER DEFAULT 0");
                if (!in_array('payment_method', $colNames)) $db->exec("ALTER TABLE invoices ADD COLUMN payment_method TEXT DEFAULT 'پرداخت آنلاین'");
                if (!in_array('admin_notes', $colNames)) $db->exec("ALTER TABLE invoices ADD COLUMN admin_notes TEXT DEFAULT ''");
                if (!in_array('address_id', $colNames)) $db->exec("ALTER TABLE invoices ADD COLUMN address_id INTEGER DEFAULT NULL");
            }
            if ($table === 'products') {
                if (!in_array('description', $colNames)) $db->exec("ALTER TABLE products ADD COLUMN description TEXT DEFAULT ''");
                if (!in_array('is_featured', $colNames)) $db->exec("ALTER TABLE products ADD COLUMN is_featured INTEGER DEFAULT 0");
                if (!in_array('created_at', $colNames)) $db->exec("ALTER TABLE products ADD COLUMN created_at TEXT DEFAULT CURRENT_TIMESTAMP");
                if (!in_array('specs', $colNames)) $db->exec("ALTER TABLE products ADD COLUMN specs TEXT DEFAULT ''");
                if (!in_array('warranty', $colNames)) $db->exec("ALTER TABLE products ADD COLUMN warranty TEXT DEFAULT '12 ماه گارانتی'");
            }
            if ($table === 'users') {
                if (!in_array('email', $colNames)) $db->exec("ALTER TABLE users ADD COLUMN email TEXT DEFAULT ''");
                if (!in_array('created_at', $colNames)) $db->exec("ALTER TABLE users ADD COLUMN created_at TEXT DEFAULT CURRENT_TIMESTAMP");
            }
        } catch (Exception $e) {}
    }

    // تنظیمات پیش‌فرض سایت - نسخه تخصصی
    $settingsCount = $db->query("SELECT COUNT(*) FROM settings")->fetchColumn();
    if ($settingsCount == 0) {
        $defaultSettings = [
            'site_name' => 'پارس سازه و آفیس',
            'site_slogan' => 'مرجع تأمین تجهیزات دفاتر فنی و عمرانی',
            'site_phone' => '۰۲۱-۸۸۷۷۶۶۵۵',
            'site_email' => 'info@parssaze.ir',
            'site_address' => 'تهران، خیابان بهشتی، ساختمان پارس',
            'site_whatsapp' => '۰۹۱۲۱۲۳۴۵۶۷',
            'site_instagram' => '@parssaze',
            'tax_rate' => '10',
            'shipping_cost' => '0',
            'free_shipping_min' => '5000000',
            'site_status' => 'فعال',
            'currency' => 'تومان',
            'invoice_prefix' => 'INV-',
            'tracking_prefix' => 'TRK-',
            'rfq_email' => 'rfq@parssaze.ir',
            'support_hours' => 'شنبه تا چهارشنبه ۸ الی ۱۷:۳۰',
            'return_days' => '7',
            'warranty_info' => 'ضمانت اصالت و ۷ روز بازگشت'
        ];
        $stmt = $db->prepare("INSERT INTO settings (key, value) VALUES (?, ?)");
        foreach ($defaultSettings as $k => $v) {
            $stmt->execute([$k, $v]);
        }
    }

    // دسته‌بندی‌های پیش‌فرض - تخصصی
    if ($db->query("SELECT COUNT(*) FROM categories")->fetchColumn() == 0) {
        $stmt = $db->prepare("INSERT INTO categories (slug, name, icon, description, product_count) VALUES (?, ?, ?, ?, ?)");
        $cats = [
            ['surveying', 'ابزار دقیق و نقشه‌برداری', '📏', 'تجهیزات نقشه‌برداری، متر لیزری، توتال استیشن، تراز لیزری', 15],
            ['hse', 'ایمنی و HSE کارگاهی', '🦺', 'کلاه ایمنی، جلیقه شبرنگ، کفش ایمنی، عینک، دستکش', 25],
            ['plotter', 'رول و چاپ نقشه', '🖨️', 'رول پلاتر، پرینتر A0-A1، جوهر پلاتر، کاغذ', 12],
            ['stationery', 'بایگانی و زونکن', '📁', 'زونکن، پوشه، کلاسور، لوازم بایگانی مهندسی', 30],
            ['tools', 'ابزار کارگاهی', '🔧', 'جعبه ابزار، دریل، ابزار دستی و برقی کارگاهی', 20],
            ['office', 'ملزومات اداری', '🏢', 'میز نقشه‌کشی، صندلی، تجهیزات دفتر فنی', 10],
            ['electrical', 'تجهیزات برقی', '⚡', 'کابل، کلید، پریز، تجهیزات برق کارگاهی', 18],
            ['measurement', 'تجهیزات اندازه‌گیری', '📐', 'کولیس، میکرومتر، متر، تراز', 14]
        ];
        foreach ($cats as $c) $stmt->execute($c);
    }

    // برندهای پیش‌فرض
    if ($db->query("SELECT COUNT(*) FROM brands")->fetchColumn() == 0) {
        $stmt = $db->prepare("INSERT INTO brands (slug, name, description, product_count) VALUES (?, ?, ?, ?)");
        $brands = [
            ['leica', 'Leica', 'برند سوئیسی تجهیزات نقشه‌برداری دقیق', 5],
            ['bosch', 'Bosch', 'برند آلمانی ابزار برقی و اندازه‌گیری', 8],
            ['jsp', 'JSP', 'برند انگلیسی تجهیزات ایمنی', 6],
            ['safetech', 'SafeTech', 'تجهیزات ایمنی کارگاهی', 10],
            ['double-a', 'Double A', 'کاغذ و ملزومات چاپ', 12],
            ['papco', 'Papco', 'لوازم بایگانی و اداری', 15],
            ['caterpillar', 'Caterpillar', 'کفش و لباس کار', 4],
            ['stanley', 'Stanley', 'ابزار دستی حرفه‌ای', 7],
            ['hp', 'HP', 'پرینتر و تجهیزات چاپ', 3]
        ];
        foreach ($brands as $b) $stmt->execute($b);
    }

    // ادمین پیش‌فرض - با دسترسی‌های تخصصی
    if ($db->query("SELECT COUNT(*) FROM admins")->fetchColumn() == 0) {
        $stmt = $db->prepare("INSERT INTO admins (username, password, name, email, role, permissions) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute(['admin', password_hash('admin123', PASSWORD_DEFAULT), 'مدیر کل سیستم', 'admin@parssaze.ir', 'مدیر کل', 'all']);
        $stmt->execute(['manager', password_hash('manager123', PASSWORD_DEFAULT), 'مدیر فروش', 'manager@parssaze.ir', 'مدیر فروش', 'orders,products,customers,rfqs']);
        $stmt->execute(['support', password_hash('support123', PASSWORD_DEFAULT), 'کارشناس پشتیبانی', 'support@parssaze.ir', 'پشتیبانی', 'orders,tickets,customers']);
    }

    // کوپن پیش‌فرض
    if ($db->query("SELECT COUNT(*) FROM coupons")->fetchColumn() == 0) {
        $stmt = $db->prepare("INSERT INTO coupons (code, title, discount_percent, min_order, max_uses, expires_at) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute(['WELCOME10', 'تخفیف خوش‌آمدگویی ۱۰٪', 10, 1000000, 100, date('Y-m-d', strtotime('+30 days'))]);
        $stmt->execute(['ENGINEER15', 'تخفیف مهندسین ۱۵٪', 15, 3000000, 50, date('Y-m-d', strtotime('+60 days'))]);
    }

    // تزریق کالاهای پیش‌فرض - تخصصی با مشخصات
    if ($db->query("SELECT COUNT(*) FROM products")->fetchColumn() == 0) {
        $stmt = $db->prepare("INSERT INTO products (name, category, brand, price, tax_id, stock, icon, description, specs, is_featured, is_new, warranty) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $seed = [
            ['متر لیزری ۱۰۰ متری لایکا Disto D2 بلوتوث‌دار', 'surveying', 'Leica', 9800000, '2710000185962', 12, '📏', 'متر لیزری حرفه‌ای با دقت 1 میلی‌متر، اتصال بلوتوث، حافظه 10 اندازه‌گیری، مناسب نقشه‌برداری', 'برد: 100متر | دقت: ±1mm | بلوتوث: دارد | باتری: لیتیومی', 1, 1, '24 ماه گارانتی لایکا'],
            ['تراز لیزری ۳۶۰ درجه سه خط سبز بوش GLL', 'surveying', 'Bosch', 16500000, '2710000185963', 6, '📐', 'تراز لیزری 360 درجه با 3 خط سبز، برد 30 متر، باتری لیتیومی، کیف حمل', 'خط: 3x360° | رنگ: سبز | برد: 30متر | IP54', 1, 0, '18 ماه گارانتی بوش'],
            ['کلاه ایمنی عایق برق مهندسی JSP کلاس E', 'hse', 'JSP', 680000, '2710000294110', 45, '⛑️', 'کلاه ایمنی استاندارد با عایق برق 20KV، قابل تنظیم، تهویه‌دار', 'استاندارد: EN397 | عایق: 20KV | وزن: 320گرم', 0, 0, '12 ماه گارانتی'],
            ['جلیقه شبرنگ ۴ جیب زیپی اعلا', 'hse', 'SafeTech', 295000, '2710000294111', 80, '🦺', 'جلیقه ایمنی شبرنگ با 4 جیب، پارچه تنفسی، سایزبندی کامل', 'جنس: پلی‌استر | شبرنگ: 5cm | سایز: M-XXL', 0, 1, '6 ماه گارانتی'],
            ['رول پلاتر تحریر ۸۰ گرم عرض ۹۰ سانت (۵۰ متری)', 'plotter', 'Double A', 740000, '2710000389104', 30, '🖨️', 'رول پلاتر با کیفیت چاپ عالی، مناسب نقشه‌های مهندسی، بدون پرز', 'گرماژ: 80gsm | عرض: 90cm | طول: 50m | مات', 1, 0, 'ضمانت کیفیت چاپ'],
            ['زونکن عطف ۸ سانت لبه فلزی پاپکو', 'stationery', 'Papco', 185000, '2710000512892', 100, '📁', 'زونکن با عطف 8 سانت، لبه فلزی مقاوم، مکانیزم قفل قوی', 'عطف: 8cm | جنس: مقوای سخت | لبه: فلزی', 0, 0, '12 ماه گارانتی'],
            ['دوربین نقشه‌برداری توتال استیشن لایکا TS07', 'surveying', 'Leica', 285000000, '2710000185964', 2, '🎯', 'توتال استیشن دقیق با دقت زاویه 1 ثانیه، برد 3500 متر', 'دقت زاویه: 1\" | برد: 3500m | حافظه: 2GB | IP55', 1, 1, '24 ماه گارانتی + آموزش'],
            ['کفش ایمنی ساق بلند CAT', 'hse', 'Caterpillar', 2450000, '2710000294112', 25, '🥾', 'کفش ایمنی با سرپنجه فولادی، ضد لغزش، ضد آب', 'سرپنجه: فولادی 200J | زیره: PU | ساق: بلند', 0, 0, '12 ماه گارانتی CAT'],
            ['کاغذ A3 تحریر 80 گرم بسته 500 برگی', 'stationery', 'Double A', 420000, '2710000512893', 60, '📄', 'کاغذ با کیفیت برای چاپ نقشه و اسناد، سفیدی 165 CIE', 'گرماژ: 80gsm | سایز: A3 | تعداد: 500 برگ | CIE: 165', 0, 0, 'ضمانت کیفیت'],
            ['جعبه ابزار فلزی 5 کشو', 'tools', 'Stanley', 3200000, '2710000601234', 15, '🧰', 'جعبه ابزار فلزی مقاوم با 5 کشو، قفل مرکزی، چرخ‌دار', 'جنس: فلز | کشو: 5 عدد | قفل: مرکزی | چرخ: 2 عدد', 0, 1, '18 ماه گارانتی Stanley'],
            ['میز نقشه‌کشی تاشو 120*80', 'office', 'Pars', 4500000, '2710000701234', 8, '🗄️', 'میز نقشه‌کشی حرفه‌ای با قابلیت تنظیم ارتفاع و زاویه', 'ابعاد: 120x80cm | تنظیم: ارتفاع + زاویه | جنس: MDF + فلز', 0, 0, '12 ماه گارانتی'],
            ['پرینتر جوهرافشان A1 اچ‌پی', 'plotter', 'HP', 45000000, '2710000389105', 3, '🖨️', 'پرینتر پلاتر حرفه‌ای با کیفیت فوق‌العاده، WiFi، رول و شیت', 'سایز: A1 | رزولوشن: 2400dpi | WiFi: دارد | جوهر: 4 رنگ', 1, 1, '12 ماه گارانتی HP'],
        ];
        foreach ($seed as $row) {
            $stmt->execute($row);
        }
    }
} catch (PDOException $e) {
    die("خطا در پایگاه داده: " . htmlspecialchars($e->getMessage()));
}

// تابع فرار از حملات XSS
function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

// تابع دریافت تنظیمات
function getSetting($key, $default = '') {
    global $db;
    try {
        $stmt = $db->prepare("SELECT value FROM settings WHERE key = ?");
        $stmt->execute([$key]);
        $val = $stmt->fetchColumn();
        return $val !== false ? $val : $default;
    } catch (Exception $e) {
        return $default;
    }
}

// تابع دریافت دسته‌بندی‌ها
function getCategories() {
    global $db;
    return $db->query("SELECT * FROM categories WHERE is_active=1 ORDER BY name")->fetchAll();
}

// تابع دریافت برندها
function getBrands() {
    global $db;
    return $db->query("SELECT * FROM brands WHERE is_active=1 ORDER BY name")->fetchAll();
}

// تابع وضعیت‌های سفارش - تخصصی
function getShippingStatuses() {
    return [
        'در حال پردازش' => ['label' => 'در حال پردازش', 'color' => '#F59E0B', 'icon' => '⏳', 'desc' => 'سفارش دریافت و در حال بررسی'],
        'تایید شده' => ['label' => 'تایید شده', 'color' => '#3B82F6', 'icon' => '✅', 'desc' => 'سفارش تایید و در حال آماده‌سازی'],
        'بسته‌بندی' => ['label' => 'بسته‌بندی', 'color' => '#6366F1', 'icon' => '📦', 'desc' => 'در حال بسته‌بندی و کنترل کیفیت'],
        'ارسال شده' => ['label' => 'ارسال شده', 'color' => '#8B5CF6', 'icon' => '🚚', 'desc' => 'به پست/باربری تحویل داده شد'],
        'در حال حمل' => ['label' => 'در حال حمل', 'color' => '#EC4899', 'icon' => '🚛', 'desc' => 'در مسیر ارسال به مشتری'],
        'تحویل داده شده' => ['label' => 'تحویل داده شده', 'color' => '#10B981', 'icon' => '✅', 'desc' => 'با موفقیت تحویل مشتری شد'],
        'لغو شده' => ['label' => 'لغو شده', 'color' => '#EF4444', 'icon' => '❌', 'desc' => 'سفارش لغو گردید'],
        'مرجوعی' => ['label' => 'مرجوعی', 'color' => '#F97316', 'icon' => '↩️', 'desc' => 'درخواست مرجوعی ثبت شد'],
    ];
}

// تابع وضعیت پرداخت
function getPaymentStatuses() {
    return [
        'پرداخت شده' => ['label' => 'پرداخت شده', 'color' => '#10B981'],
        'در انتظار پرداخت' => ['label' => 'در انتظار پرداخت', 'color' => '#F59E0B'],
        'پرداخت ناموفق' => ['label' => 'پرداخت ناموفق', 'color' => '#EF4444'],
        'استرداد شده' => ['label' => 'استرداد شده', 'color' => '#6366F1'],
    ];
}

// تابع لاگ فعالیت
function logActivity($action, $desc='', $userId=null, $adminId=null) {
    global $db;
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $stmt = $db->prepare("INSERT INTO activity_logs (user_id, admin_id, action, description, ip, created_at) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $adminId, $action, $desc, $ip, date('Y/m/d H:i:s')]);
    } catch (Exception $e) {}
}
