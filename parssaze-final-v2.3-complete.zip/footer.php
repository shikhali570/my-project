</div> <!-- پایان page-wrapper -->

<div class="modal-overlay" id="authModal">
  <div class="auth-card">
    <div class="auth-header">
      <button onclick="closeModal('authModal')" style="position:absolute;left:18px;top:18px;background:rgba(255,255,255,.15);border:none;color:#fff;width:32px;height:32px;border-radius:50%;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center">✕</button>
      <div style="width:56px;height:56px;background:linear-gradient(135deg,var(--blue),#60A5FA);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:24px">👤</div>
      <h3 style="font-size:17px;font-weight:900">ورود به پنل مشتریان</h3>
      <p>ورود سریع با شماره همراه - بدون نیاز به رمز عبور</p>
    </div>
    <form method="POST" action="index.php" style="padding:24px">
      <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
      <div class="input-group">
        <label><i class="fa-solid fa-user"></i> نام و نام‌خانوادگی رابط</label>
        <input type="text" name="name" placeholder="مثلاً: مهندس علوی" required>
      </div>
      <div class="input-group">
        <label><i class="fa-solid fa-building"></i> نام شرکت یا مؤسسه</label>
        <input type="text" name="company" placeholder="مثلاً: شرکت مهندسی بناسازان">
      </div>
      <div class="input-group">
        <label><i class="fa-solid fa-envelope"></i> ایمیل (اختیاری)</label>
        <input type="email" name="email" placeholder="info@company.com">
      </div>
      <div class="input-group">
        <label><i class="fa-solid fa-phone"></i> شماره تلفن همراه *</label>
        <input type="text" name="phone" required maxlength="11" placeholder="۰۹۱۲XXXXXXX" style="letter-spacing:1px">
        <small style="color:var(--g500);font-size:11px;margin-top:4px;display:block"><i class="fa-solid fa-shield-halved"></i> ورود شما امن است و شماره شما محرمانه می‌ماند</small>
      </div>
      <button type="submit" name="btn_login" class="btn btn-primary" style="width:100%;padding:12px;margin-top:8px;font-size:14px"><i class="fa-solid fa-right-to-bracket"></i> ورود به حساب کاربری</button>
      
      <div style="margin-top:16px;background:var(--g50);border-radius:10px;padding:12px;font-size:11.5px;color:var(--g700)">
        <strong style="color:var(--navy)"><i class="fa-solid fa-gift"></i> مزایای عضویت:</strong>
        <ul style="margin:6px 16px 0 0;line-height:1.8">
          <li>پیگیری آنی سفارشات با کد رهگیری</li>
          <li>سابقه خرید و سفارش مجدد سریع</li>
          <li>دریافت پیش‌فاکتور رسمی با تخفیف سازمانی</li>
          <li>اعتبار مالیاتی ارزش افزوده</li>
        </ul>
      </div>

      <div style="text-align:center;margin-top:14px;font-size:11px;color:var(--g500)">
        با ورود، <a href="#" style="color:var(--blue)">قوانین و مقررات</a> را می‌پذیرید
      </div>
    </form>
  </div>
</div>

<!-- مودال پیگیری سریع -->
<div class="modal-overlay" id="trackModal">
  <div class="auth-card" style="max-width:400px">
    <div class="auth-header">
      <button onclick="closeModal('trackModal')" style="position:absolute;left:18px;top:18px;background:rgba(255,255,255,.15);border:none;color:#fff;width:32px;height:32px;border-radius:50%;cursor:pointer">✕</button>
      <h3 style="font-size:16px;font-weight:800"><i class="fa-solid fa-truck-fast"></i> پیگیری سریع سفارش</h3>
      <p>کد پیگیری خود را وارد کنید</p>
    </div>
    <form onsubmit="trackOrderSubmit(event)" style="padding:20px">
      <div class="input-group">
        <input type="text" id="quickTrackInput" placeholder="TRK-123456" style="text-align:center;letter-spacing:1px;font-weight:700;padding:14px;font-size:15px">
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%"><i class="fa-solid fa-magnifying-glass"></i> رهگیری سفارش</button>
    </form>
  </div>
</div>

<footer class="site-footer no-print">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-col">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
          <div style="width:40px;height:40px;background:linear-gradient(135deg,#1C2541,var(--blue));border-radius:10px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px">🏗️</div>
          <div><strong style="color:#fff;font-size:14px"><?= e(getSetting('site_name','پارس سازه و آفیس')) ?></strong><br><small style="color:var(--g400)"><?= e(getSetting('site_slogan')) ?></small></div>
        </div>
        <p style="line-height:1.8;color:var(--g400);font-size:12.5px">مرجع تخصصی تأمین تجهیزات مهندسی، ابزار دقیق، ایمنی کارگاهی و ملزومات دفاتر فنی با صدور فاکتور رسمی مورد تایید سامانه مؤدیان دارایی.</p>
        <div style="display:flex;gap:8px;margin-top:14px">
          <a href="#" style="width:32px;height:32px;background:rgba(255,255,255,.08);border-radius:8px;display:flex;align-items:center;justify-content:center"><i class="fa-brands fa-instagram"></i></a>
          <a href="#" style="width:32px;height:32px;background:rgba(255,255,255,.08);border-radius:8px;display:flex;align-items:center;justify-content:center"><i class="fa-brands fa-telegram"></i></a>
          <a href="#" style="width:32px;height:32px;background:rgba(255,255,255,.08);border-radius:8px;display:flex;align-items:center;justify-content:center"><i class="fa-brands fa-whatsapp"></i></a>
        </div>
      </div>
      <div class="footer-col">
        <h4><i class="fa-solid fa-link"></i> دسترسی سریع</h4>
        <a href="index.php?page=home"><i class="fa-solid fa-chevron-left" style="font-size:10px"></i> کاتالوگ محصولات</a>
        <a href="index.php?page=track"><i class="fa-solid fa-chevron-left" style="font-size:10px"></i> پیگیری سفارش</a>
        <a href="index.php?page=rfq"><i class="fa-solid fa-chevron-left" style="font-size:10px"></i> استعلام قیمت (RFQ)</a>
        <a href="index.php?page=dashboard&tab=history"><i class="fa-solid fa-chevron-left" style="font-size:10px"></i> سابقه خرید</a>
        <a href="admin.php"><i class="fa-solid fa-chevron-left" style="font-size:10px"></i> پنل مدیریت</a>
      </div>
      <div class="footer-col">
        <h4><i class="fa-solid fa-headset"></i> پشتیبانی</h4>
        <a href="#"><i class="fa-solid fa-phone"></i> <?= e(getSetting('site_phone')) ?></a>
        <a href="#"><i class="fa-solid fa-envelope"></i> <?= e(getSetting('site_email')) ?></a>
        <a href="#"><i class="fa-solid fa-clock"></i> شنبه تا چهارشنبه ۸ الی ۱۷:۳۰</a>
        <a href="#"><i class="fa-solid fa-location-dot"></i> <?= e(getSetting('site_address')) ?></a>
      </div>
      <div class="footer-col">
        <h4><i class="fa-solid fa-shield-halved"></i> نماد اعتماد</h4>
        <div style="background:rgba(255,255,255,.06);border-radius:10px;padding:12px;text-align:center">
          <div style="font-size:32px">🛡️</div>
          <div style="font-size:11px;margin-top:6px">دارای مجوز رسمی<br>اتصال به سامانه مؤدیان<br>پرداخت امن</div>
          <div style="display:flex;gap:6px;justify-content:center;margin-top:10px">
            <span style="background:var(--green);color:#fff;padding:2px 8px;border-radius:20px;font-size:10px">✓ SSL امن</span>
            <span style="background:var(--blue);color:#fff;padding:2px 8px;border-radius:20px;font-size:10px">✓ فاکتور رسمی</span>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div>© ۱۴۰۳ تمامی حقوق مادی و معنوی برای «<?= e(getSetting('site_name')) ?>» محفوظ است. | نسخه ۲.۰ - پنل مدیریت و پیگیری سفارشات</div>
      <div style="display:flex;gap:12px;align-items:center">
        <span><i class="fa-solid fa-lock"></i> پرداخت امن</span>
        <span><i class="fa-solid fa-certificate"></i> متصل به سامانه مؤدیان</span>
        <span>طراحی شده با ❤️ برای مهندسان ایران</span>
      </div>
    </div>
  </div>
</footer>

<script src="app.js"></script>
</body>
</html>
