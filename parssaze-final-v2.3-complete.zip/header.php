<?php
require_once 'config.php';
$cartCount = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
$currentPage = $_GET['page'] ?? 'home';
$currentCat = $_GET['cat'] ?? '';
$siteName = getSetting('site_name', 'پارس سازه و آفیس');
$siteSlogan = getSetting('site_slogan', 'مرجع تأمین تجهیزات دفاتر فنی و عمرانی');
$sitePhone = getSetting('site_phone', '۰۲۱-۸۸۷۷۶۶۵۵');
$isLogged = !empty($_SESSION['user']);
$userDisplay = $isLogged ? ($_SESSION['user']['company'] ?? $_SESSION['user']['name']) : '';
$categories = getCategories();
$wishlistCountHeader = 0;
if ($isLogged) {
    try {
        $stmt = $db->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = ?");
        $stmt->execute([$_SESSION['user']['id']]);
        $wishlistCountHeader = $stmt->fetchColumn();
    } catch (Exception $e) {}
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($siteName) ?> | تامین تجهیزات مهندسی و کارگاهی - پنل تخصصی</title>
  <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="top-bar no-print">
  <div class="container flex-between">
    <div class="top-links">
      <a href="index.php?page=home"><i class="fa-solid fa-store"></i> کاتالوگ تجهیزات</a>
      <a href="index.php?page=track"><i class="fa-solid fa-truck-fast"></i> پیگیری سفارش</a>
      <a href="index.php?page=dashboard&tab=history"><i class="fa-solid fa-clock-rotate-left"></i> سابقه خرید</a>
      <a href="index.php?page=dashboard&tab=wishlist"><i class="fa-solid fa-heart"></i> علاقه‌مندی</a>
      <a href="index.php?page=rfq"><i class="fa-solid fa-file-invoice"></i> استعلام RFQ</a>
      <a href="index.php?page=about"><i class="fa-solid fa-circle-info"></i> درباره ما</a>
    </div>
    <div class="top-contact">
      <span><i class="fa-solid fa-phone"></i> <?= e($sitePhone) ?></span>
      <span class="hide-mobile">| <?= e(getSetting('support_hours','شنبه تا چهارشنبه ۸ الی ۱۷:۳۰')) ?></span>
      <a href="admin.php" style="margin-right:12px;color:#FDE68A"><i class="fa-solid fa-user-shield"></i> پنل مدیریت تخصصی</a>
    </div>
  </div>
</div>

<div class="modiyan-strip no-print">
  <div class="container flex-center gap-10">
    <span class="badge-gold"><i class="fa-solid fa-certificate"></i> سامانه مؤدیان</span>
    <span>صدور آنی فاکتور رسمی نوع ۱ با شناسه ۲۲ رقمی و انتقال اعتبار ارزش افزوده - نسخه تخصصی 2.1 بدون منوی از قلم افتاده</span>
    <span class="badge badge-green hide-mobile">✓ متصل به دارایی</span>
  </div>
</div>

<header class="header no-print">
  <div class="container flex-between">
    <a href="index.php?page=home" class="logo">
      <div class="logo-icon">🏗️</div>
      <div>
        <div class="logo-title"><?= e($siteName) ?></div>
        <small><?= e($siteSlogan) ?> - پنل تخصصی</small>
      </div>
    </a>

    <div class="header-search hide-mobile">
      <form method="GET" action="index.php" class="search-box">
        <input type="hidden" name="page" value="home">
        <input type="text" name="q" placeholder="جستجوی تخصصی تجهیزات، برند، کد مالیاتی، مشخصات..." value="<?= e($_GET['q'] ?? '') ?>">
        <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
      </form>
    </div>

    <div class="header-actions">
      <a href="index.php?page=track" class="btn btn-secondary btn-icon hide-mobile" title="پیگیری تخصصی سفارش">
        <i class="fa-solid fa-location-dot"></i> پیگیری
      </a>

      <?php if ($isLogged): ?>
        <a href="index.php?page=dashboard&tab=wishlist" class="btn btn-secondary btn-icon hide-mobile" title="علاقه‌مندی‌ها">
          <i class="fa-solid fa-heart" style="color:#EC4899"></i>
          <?php if ($wishlistCountHeader>0): ?><span class="badge-count" style="background:#EC4899"><?= $wishlistCountHeader ?></span><?php endif; ?>
        </a>

        <div class="user-dropdown-wrapper">
          <button class="btn btn-secondary user-btn" onclick="toggleUserMenu()">
            <span class="avatar-tag"><?= mb_substr($userDisplay, 0, 1) ?></span>
            <span class="hide-mobile"><?= e(mb_substr($userDisplay, 0, 12)) ?></span>
            <i class="fa-solid fa-chevron-down" style="font-size:10px"></i>
          </button>
          <div class="user-dropdown" id="userDropdown" style="min-width:280px">
            <div class="user-dropdown-header" style="background:linear-gradient(135deg,var(--navy),var(--navy-light));color:#fff">
              <div style="display:flex;align-items:center;gap:10px">
                <div style="width:40px;height:40px;background:linear-gradient(135deg,var(--blue),#60A5FA);border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:900"><?= mb_substr($userDisplay,0,1) ?></div>
                <div><strong style="color:#fff"><?= e($userDisplay) ?></strong><br><small style="color:#94A3B8"><?= e($_SESSION['user']['phone']) ?> | <?= e($_SESSION['user']['province'] ?? 'تهران') ?></small></div>
              </div>
              <div style="margin-top:10px;display:flex;gap:6px">
                <span style="background:rgba(255,255,255,.15);padding:2px 8px;border-radius:10px;font-size:10px;color:#fff">مشتری ویژه</span>
                <span style="background:rgba(16,185,129,.2);color:#6EE7B7;padding:2px 8px;border-radius:10px;font-size:10px">تایید شده</span>
              </div>
            </div>
            
            <div style="padding:8px 0">
              <div style="font-size:10px;font-weight:800;color:#64748B;padding:6px 14px">سفارشات و خرید</div>
              <a href="index.php?page=dashboard&tab=overview"><i class="fa-solid fa-gauge-high"></i> نمای کلی 360°</a>
              <a href="index.php?page=dashboard&tab=orders"><i class="fa-solid fa-receipt"></i> سفارشات من</a>
              <a href="index.php?page=dashboard&tab=track"><i class="fa-solid fa-truck-fast"></i> پیگیری مرسولات</a>
              <a href="index.php?page=dashboard&tab=history"><i class="fa-solid fa-clock-rotate-left"></i> سابقه خرید تخصصی</a>
              <a href="index.php?page=dashboard&tab=invoices"><i class="fa-solid fa-file-invoice-dollar"></i> فاکتورهای مالیاتی</a>
              
              <div style="font-size:10px;font-weight:800;color:#64748B;padding:8px 14px 4px;margin-top:4px;border-top:1px solid var(--g100)">علاقه‌مندی و آدرس</div>
              <a href="index.php?page=dashboard&tab=wishlist"><i class="fa-solid fa-heart" style="color:#EC4899"></i> علاقه‌مندی‌ها <?= $wishlistCountHeader>0?"<span style='margin-right:auto;background:#EC4899;color:#fff;padding:2px 6px;border-radius:10px;font-size:10px'>$wishlistCountHeader</span>":'' ?></a>
              <a href="index.php?page=dashboard&tab=addresses"><i class="fa-solid fa-location-dot" style="color:var(--red)"></i> آدرس‌های من</a>
              
              <div style="font-size:10px;font-weight:800;color:#64748B;padding:8px 14px 4px;margin-top:4px;border-top:1px solid var(--g100)">پشتیبانی و مالی</div>
              <a href="index.php?page=dashboard&tab=rfq"><i class="fa-solid fa-file-circle-question" style="color:var(--orange)"></i> استعلام‌ها (RFQ)</a>
              <a href="index.php?page=dashboard&tab=tickets"><i class="fa-solid fa-headset"></i> تیکت پشتیبانی</a>
              <a href="index.php?page=dashboard&tab=financial"><i class="fa-solid fa-sack-dollar" style="color:var(--green)"></i> امور مالی و اعتباری</a>
              
              <div style="font-size:10px;font-weight:800;color:#64748B;padding:8px 14px 4px;margin-top:4px;border-top:1px solid var(--g100)">حساب کاربری</div>
              <a href="index.php?page=dashboard&tab=profile"><i class="fa-solid fa-user-gear"></i> پروفایل شرکت</a>
              <a href="index.php?page=dashboard&tab=security"><i class="fa-solid fa-shield-halved"></i> امنیت</a>
            </div>
            
            <div class="dropdown-divider"></div>
            <a href="index.php?action=logout" class="text-red"><i class="fa-solid fa-right-from-bracket"></i> خروج از حساب تخصصی</a>
          </div>
        </div>
      <?php else: ?>
        <button class="btn btn-secondary" onclick="openModal('authModal')">
          <i class="fa-solid fa-user"></i> <span class="hide-mobile">ورود / ثبت‌نام تخصصی</span>
        </button>
      <?php endif; ?>

      <a href="index.php?page=cart" class="btn btn-primary cart-btn">
        <i class="fa-solid fa-cart-shopping"></i>
        <span class="hide-mobile">سبد</span>
        <span class="badge-count"><?= $cartCount ?></span>
      </a>
    </div>
  </div>

  <div class="container mobile-search show-mobile-only">
    <form method="GET" action="index.php" class="search-box">
      <input type="hidden" name="page" value="home">
      <input type="text" name="q" placeholder="جستجوی تخصصی محصولات..." value="<?= e($_GET['q'] ?? '') ?>">
      <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
  </div>
</header>

<nav class="nav no-print">
  <div class="container">
    <div class="nav-scroll">
      <a class="nav-link <?= $currentPage === 'home' && !$currentCat ? 'active' : '' ?>" href="index.php?page=home"><i class="fa-solid fa-border-all"></i> همه تجهیزات</a>
      <?php foreach ($categories as $cat): ?>
        <a class="nav-link <?= $currentCat === $cat['slug'] ? 'active' : '' ?>" href="index.php?page=home&cat=<?= e($cat['slug']) ?>"><?= $cat['icon'] ?> <?= e($cat['name']) ?></a>
      <?php endforeach; ?>
      <a class="nav-link rfq" href="index.php?page=rfq"><i class="fa-solid fa-file-circle-question"></i> استعلام RFQ</a>
      <a class="nav-link" href="index.php?page=track"><i class="fa-solid fa-truck-fast"></i> پیگیری تخصصی</a>
      <a class="nav-link" href="index.php?page=dashboard&tab=wishlist"><i class="fa-solid fa-heart"></i> علاقه‌مندی</a>
    </div>
  </div>
</nav>

<div class="container page-wrapper">
